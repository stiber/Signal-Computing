# LaTeX2HTML 2K.1beta (1.50)
# Associate internals original text with physical files.


$key = q/fig:zt-conv-etet/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-conv/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-expoZ/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-w/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-pfe/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:izt/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-HX/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-hx/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:izt-w/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-expoF/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-expof/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/alg:convolution/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:convolution/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:zt-expo-r0.5z/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-delta/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/fg:convex/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-conv-exp/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:zt-expo-r1F/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt-expo-cF/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:zt/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:zt-expo-r0.5f/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:zt-expo-r0.5F/;
$ref_files{$key} = "$dir".q|module6.html|; 
$noresave{$key} = "$nosave";

1;

