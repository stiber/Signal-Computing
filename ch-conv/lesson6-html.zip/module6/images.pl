# LaTeX2HTML 2K.1beta (1.50)
# Associate images original text with physical files.


$key = q/displaystylesum_{k=0}^{infty}(alphaz^{-1})^k;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="99" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img70.gif"
 ALT="$\displaystyle \sum_{k=0}^{\infty}(\alpha z^{-1})^k$">|; 

$key = q/r=1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img30.gif"
 ALT="$ r=1$">|; 

$key = q/{figure}center{{epsfig{file=zt_expo_r0.5F.eps,width=3.5in}{{{center{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="402" HEIGHT="321" BORDER="0"
 SRC="|."$dir".q|img88.gif"
 ALT="\begin{figure}\begin{center}
\epsfig{file=zt_expo_r0.5F.eps,width=3.5in}\end{center}\end{figure}">|; 

$key = q/displaystylex_k={1,-3,2,1},quadk=0,1,2,3;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="285" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img222.gif"
 ALT="$\displaystyle x_k = \{1, -3, 2, 1\}, \quad k = 0,1,2,3$">|; 

$key = q/displaystylefrac{A_1}{(z-1)}+frac{A_2}{(z-0.5)};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="172" HEIGHT="63" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img303.gif"
 ALT="$\displaystyle \frac{A_1}{(z-1)} + \frac{A_2}{(z-0.5)}$">|; 

$key = q/y_{t-k}=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img238.gif"
 ALT="$ y_{t-k}=0$">|; 

$key = q/z^2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img296.gif"
 ALT="$ z^2$">|; 

$key = q/x_k*y_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img207.gif"
 ALT="$ x_k*y_k$">|; 

$key = q/displaystylesum_{k=0}^{t}e^ke^{t-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="89" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img169.gif"
 ALT="$\displaystyle \sum_{k=0}^{t}e^ke^{t-k}$">|; 

$key = q/alpha=1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img89.gif"
 ALT="$ \alpha=1$">|; 

$key = q/displaystylesum_{k=-infty}^{infty}delta_kz^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="99" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img44.gif"
 ALT="$\displaystyle \sum_{k=-\infty}^{\infty} \delta_k z^{-k}$">|; 

$key = q/displaystylew_2;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img245.gif"
 ALT="$\displaystyle w_2$">|; 

$key = q/omega=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img104.gif"
 ALT="$ \omega=0$">|; 

$key = q/displaystylemathcal{Y}(z)=frac{z^2}{z^2-1.5z+0.5};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="203" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img297.gif"
 ALT="$\displaystyle \mathcal{Y}(z) = \frac{z^2}{z^2-1.5z+0.5}$">|; 

$key = q/Z{cdot};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img196.gif"
 ALT="$ Z\{\cdot\}$">|; 

$key = q/displaystyleR^kcos(ktheta),quadkge0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="171" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img121.gif"
 ALT="$\displaystyle R^k\cos(k\theta), \quad k\ge 0$">|; 

$key = q/X*H=e^t*e^t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img193.gif"
 ALT="$ X*H =e^t*e^t$">|; 

$key = q/z=p_1=1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img308.gif"
 ALT="$ z = p_1=1$">|; 

$key = q/displaystylemathcal{Y}(z)=mathcal{H}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="114" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img267.gif"
 ALT="$\displaystyle \mathcal{Y}(z)= \mathcal{H}(z)$">|; 

$key = q/z=e^{jomega};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="56" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.gif"
 ALT="$ z=e^{j\omega}$">|; 

$key = q/displaystylesum_{k=-infty}^{infty}delta_{k-n}z^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="119" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.gif"
 ALT="$\displaystyle \sum_{k=-\infty}^{\infty} \delta_{k-n} z^{-k}$">|; 

$key = q/displaystylemathcal{F}(z)=1+2z^{-1}+5z^{-2}+7z^{-3}+z^{-5};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="326" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.gif"
 ALT="$\displaystyle \mathcal{F}(z)=1+2z^{-1}+5z^{-2}+7z^{-3}+z^{-5}$">|; 

$key = q/delta;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img40.gif"
 ALT="$ \delta$">|; 

$key = q/displaystyleY=X*H;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img142.gif"
 ALT="$\displaystyle Y = X * H$">|; 

$key = q/p_2=0.5;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img300.gif"
 ALT="$ p_2=0.5$">|; 

$key = q/r;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.gif"
 ALT="$ r$">|; 

$key = q/z=1slash2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="59" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img277.gif"
 ALT="$ z=1/2$">|; 

$key = q/-k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="26" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img190.gif"
 ALT="$ -k$">|; 

$key = q/a_1mathcal{X}(z)+a_2mathcal{Y}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="124" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img198.gif"
 ALT="$ a_1\mathcal{X}(z)+a_2\mathcal{Y}(z)$">|; 

$key = q/|alphaz^{-1}|<1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img76.gif"
 ALT="$ \vert\alpha
z^{-1}\vert&lt;1$">|; 

$key = q/t=0,1,2,ldots,;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img167.gif"
 ALT="$ t=0,1,2,\ldots,
$">|; 

$key = q/displaystyledelta_{k-n}stackrel{mathbf{Z}}{longleftrightarrow}frac{1}{z^n},quadn>0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="190" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img59.gif"
 ALT="$\displaystyle \delta_{k-n}\stackrel{\mathbf{Z}}{\longleftrightarrow} \frac{1}{z^n}, \quad n&gt;0$">|; 

$key = q/h_t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img147.gif"
 ALT="$ h_t$">|; 

$key = q/displaystylesum_{t=-infty}^{infty}w_tz^{-t};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img215.gif"
 ALT="$\displaystyle \sum_{t=-\infty}^{\infty}w_tz^{-t}$">|; 

$key = q/p_2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img282.gif"
 ALT="$ p_2$">|; 

$key = q/alpha=1slash2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img80.gif"
 ALT="$ \alpha=1/2$">|; 

$key = q/displaystylemathcal{F}(z)=frac{1}{1-alphaz^{-1}},quad|z|>|alpha|;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="254" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img78.gif"
 ALT="$\displaystyle \mathcal{F}(z)=\frac{1}{1-\alpha z^{-1}}, \quad \vert z\vert&gt;\vert\alpha\vert$">|; 

$key = q/displaystylex_0y_1+x_1y_0=1-3=-2;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="225" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img244.gif"
 ALT="$\displaystyle x_0 y_1+x_1 y_0= 1-3=-2$">|; 

$key = q/displaystylef_k=frac{1}{j2pi}oint_Cmathcal{F}(z)z^{k-1}dz;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="213" HEIGHT="63" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.gif"
 ALT="$\displaystyle f_k = \frac{1}{j2\pi}\oint_C\mathcal{F}(z)z^{k-1}dz$">|; 

$key = q/vec{1};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img165.gif"
 ALT="$ \vec{1}$">|; 

$key = q/H;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img145.gif"
 ALT="$ H$">|; 

$key = q/mathcal{X}(z^{-1});MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img204.gif"
 ALT="$ \mathcal{X}(z^{-1})$">|; 

$key = q/x_t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img146.gif"
 ALT="$ x_t$">|; 

$key = q/displaystyleF(omega);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img98.gif"
 ALT="$\displaystyle F(\omega)$">|; 

$key = q/displaystylef_k={1,1,1,ldots},quadkge0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="225" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img91.gif"
 ALT="$\displaystyle f_k = \{1, 1, 1, \ldots\}, \quad k \ge 0$">|; 

$key = q/x_k=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img150.gif"
 ALT="$ x_k = 0$">|; 

$key = q/A_1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img304.gif"
 ALT="$ A_1$">|; 

$key = q/e^{-jpislash2}=cospislash2-jsinpislash2=0-jtimes1=-j;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="330" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img135.gif"
 ALT="$ e^{-j\pi/2}=\cos\pi/2-j\sin\pi/2=0-j \times 1=-j$">|; 

$key = q/Y(omega);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="41" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img271.gif"
 ALT="$ Y(\omega)$">|; 

$key = q/displaystyledelta_{k-n};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img48.gif"
 ALT="$\displaystyle \delta_{k-n}$">|; 

$key = q/displaystylef_k=u_0=left{{array}{ll}1&kge00&k<0{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="203" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img90.gif"
 ALT="$\displaystyle f_k = u_0 = \left\{\begin{array}{ll} 1 &amp; k \ge 0 \ 0 &amp; k &lt; 0 \end{array}\right.$">|; 

$key = q/X;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img144.gif"
 ALT="$ X$">|; 

$key = q/displaystylex_0y_2+x_1y_1+x_2y_0=0-3+2=-1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="320" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img246.gif"
 ALT="$\displaystyle x_0 y_2+x_1 y_1+x_2 y_0=0-3+2=-1$">|; 

$key = q/displaystylemathcal{Y}(z)sum_{k=-infty}^{infty}x_kz^{-k}=mathcal{Y}(z)mathcal{X}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="255" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img220.gif"
 ALT="$\displaystyle \mathcal{Y}(z)\sum_{k=-\infty}^{\infty}x_k z^{-k}
= \mathcal{Y}(z) \mathcal{X}(z)$">|; 

$key = q/displaystylefrac{mathcal{Y}(z)}{z}=frac{2}{(z-1)}-frac{1}{(z-0.5)};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="243" HEIGHT="66" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img312.gif"
 ALT="$\displaystyle \frac{\mathcal{Y}(z)}{z} = \frac{2}{(z-1)} - \frac{1}{(z-0.5)}$">|; 

$key = q/C;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.gif"
 ALT="$ C$">|; 

$key = q/displaystyledelta_kstackrel{mathbf{Z}}{longleftrightarrow}1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="53" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img46.gif"
 ALT="$\displaystyle \delta_k\stackrel{\mathbf{Z}}{\longleftrightarrow} 1$">|; 

$key = q/n_h=2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.gif"
 ALT="$ n_h=2$">|; 

$key = q/displaystylemathcal{W}(z)=sum_{k=-infty}^{infty}x_kleft(sum_{t=-infty}^{infty}y_{t-k}z^{-t}right);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="287" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img218.gif"
 ALT="$\displaystyle \mathcal{W}(z) = \sum_{k=-\infty}^{\infty}x_k \left(\sum_{t=-\infty}^{\infty}y_{t-k}z^{-t}\right)$">|; 

$key = q/h;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img149.gif"
 ALT="$ h$">|; 

$key = q/displaystylefrac{1}{1-R(costheta+jsintheta)z^{-1}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="216" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img115.gif"
 ALT="$\displaystyle \frac{1}{1-R(\cos\theta+j \sin\theta )z^{-1}}$">|; 

$key = q/mathcal{X}(a^{-1}z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img202.gif"
 ALT="$ \mathcal{X}(a^{-1}z)$">|; 

$key = q/displaystylet^2-frac{t(t+1)}{2}=frac{t(t-1)}{2}net;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="240" HEIGHT="66" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img177.gif"
 ALT="$\displaystyle t^2 - \frac{t(t+1)}{2} =\frac{t(t-1)}{2} \ne t$">|; 

$key = q/displaystylefrac{1}{j2pi}oint_Cmathcal{F}(e^{jomega})e^{j(k-1)omega}de^{jomega};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="226" HEIGHT="63" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.gif"
 ALT="$\displaystyle \frac{1}{j2\pi}\oint_C\mathcal{F}(e^{j\omega})
e^{j(k-1)\omega}de^{j\omega}$">|; 

$key = q/displaystyley_t=sum_{k=-infty}^{infty}x_kh_{t-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="150" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img140.gif"
 ALT="$\displaystyle y_t = \sum_{k=-\infty}^{\infty}x_k h_{t-k}$">|; 

$key = q/displaystyle1z^{n}=z^{n};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img65.gif"
 ALT="$\displaystyle 1z^{n}=z^{n}$">|; 

$key = q/x;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img148.gif"
 ALT="$ x$">|; 

$key = q/displaystylef_k=left{{array}{ll}R^ke^{jktheta}&quadkge00&quadk<0{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="223" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img111.gif"
 ALT="$\displaystyle f_k = \left\{\begin{array}{ll} R^ke^{jk\theta} &amp; \quad k \ge 0 \ 0 &amp; \quad k &lt; 0 \end{array}\right.$">|; 

$key = q/displaystylemathcal{F}(z)equivsum_{k=-infty}^{infty}f_kz^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="169" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.gif"
 ALT="$\displaystyle \mathcal{F}(z) \equiv \sum_{k=-\infty}^{\infty} f_kz^{-k}$">|; 

$key = q/F(omega);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.gif"
 ALT="$ F(\omega)$">|; 

$key = q/displaystylefrac{1-Rcosthetaz^{-1}}{1-2Rcosthetaz^{-1}+R^2z^{-2}}+jfrac{Rsinthetaz^{-1}}{1-2Rcosthetaz^{-1}+R^2z^{-2}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="462" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img119.gif"
 ALT="$\displaystyle \frac{1-R\cos\theta z^{-1}}
{1-2R\cos\theta z^{-1} + R^2 z^{-2}}
+j\frac{R\sin\theta z^{-1}}
{1-2R\cos\theta z^{-1} + R^2 z^{-2}}$">|; 

$key = q/displaystyleW=X*Y=sum_{k=-infty}^{infty}x_ky_{t-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="234" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img212.gif"
 ALT="$\displaystyle W = X*Y = \sum_{k=-\infty}^{\infty}x_k y_{t-k}$">|; 

$key = q/A_kslash(1-p_1z^{-1});MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img288.gif"
 ALT="$ A_k/(1-p_1z^{-1})$">|; 

$key = q/displaystylefrac{1}{1-Re^{jtheta}z^{-1}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img114.gif"
 ALT="$\displaystyle \frac{1}{1-Re^{j\theta}z^{-1}}$">|; 

$key = q/displaystyley_{t-1}stackrel{mathbf{Z}}{longleftrightarrow}z^{-1}mathcal{Y}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="156" HEIGHT="53" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img274.gif"
 ALT="$\displaystyle y_{t-1}\stackrel{\mathbf{Z}}{\longleftrightarrow} z^{-1}\mathcal{Y}(z)$">|; 

$key = q/{figure}center{{epsfig{file=zt_expo_rz.eps,width=4in}{{{center{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="461" HEIGHT="364" BORDER="0"
 SRC="|."$dir".q|img84.gif"
 ALT="\begin{figure}\begin{center}
\epsfig{file=zt_expo_rz.eps,width=4in}\end{center}\end{figure}">|; 

$key = q/mathcal{H}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img258.gif"
 ALT="$ \mathcal{H}(z)$">|; 

$key = q/displaystylez=A_1(z-0.5)+A_2(z-1);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="246" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img307.gif"
 ALT="$\displaystyle z= A_1(z-0.5) + A_2(z-1)$">|; 

$key = q/displaystylefrac{e^{j(omegaslash2-pislash2)}}{2sinomegaslash2},quadomegane2pik,k=0,1,ldots;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="302" HEIGHT="70" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img102.gif"
 ALT="$\displaystyle \frac{e^{j(\omega/2-\pi/2)}}{2\sin\omega/2}, \quad \omega\ne
2\pi k, k=0,1,\ldots$">|; 

$key = q/displaystyleR^ksin(ktheta)stackrel{mathbf{Z}}{longleftrightarrow}frac{Rsinthetaz^{-1}}{1-2Rcosthetaz^{-1}+R^2z^{-2}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="357" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img125.gif"
 ALT="$\displaystyle R^k\sin(k\theta)\stackrel{\mathbf{Z}}{\longleftrightarrow}  \frac{R\sin\theta z^{-1}} {1-2R\cos\theta z^{-1} + R^2 z^{-2}}$">|; 

$key = q/displaystylemathcal{W}(z)=mathcal{X}(z)mathcal{Y}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img229.gif"
 ALT="$\displaystyle \mathcal{W}(z)=\mathcal{X}(z)\mathcal{Y}(z)$">|; 

$key = q/displaystylef_k=left{{array}{ll}alpha^k&quadkge00&quadk<0{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="189" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img66.gif"
 ALT="$\displaystyle f_k = \left\{\begin{array}{ll} \alpha^k &amp; \quad k \ge 0 \ 0 &amp; \quad k &lt; 0 \end{array}\right.$">|; 

$key = q/displaystyleleft{{array}{ll}1&k=-n0&kneq-n{array}right.,quadn>0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="210" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img51.gif"
 ALT="$\displaystyle \left\{\begin{array}{ll}
1 &amp; k=-n \\\\
0 &amp; k \neq -n
\end{array}\right., \quad n&gt;0$">|; 

$key = q/-j=e^{-jpislash2};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="89" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img103.gif"
 ALT="$ -j=e^{-j\pi/2}$">|; 

$key = q/displaystylea^kstackrel{mathbf{Z}}{longleftrightarrow}frac{1}{1-az^{-1}},quadkge0,|z|>a;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="293" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img278.gif"
 ALT="$\displaystyle a^k\stackrel{\mathbf{Z}}{\longleftrightarrow} \frac{1}{1-az^{-1}}, \quad k \ge 0, \vert z\vert&gt;a$">|; 

$key = q/x_kh_{t-k};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img183.gif"
 ALT="$ x_kh_{t-k}$">|; 

$key = q/N;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img280.gif"
 ALT="$ N$">|; 

$key = q/displaystylesum_{k=-infty}^{infty}f_kz^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img68.gif"
 ALT="$\displaystyle \sum_{k=-\infty}^{\infty} f_k z^{-k}$">|; 

$key = q/displaystyleY(omega)=H(omega)X(omega);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="168" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img269.gif"
 ALT="$\displaystyle Y(\omega)=H(\omega)X(\omega)$">|; 

$key = q/displaystylef_kstackrel{mathbf{Z}}{longleftrightarrow}mathcal{F}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="53" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.gif"
 ALT="$\displaystyle f_k\stackrel{\mathbf{Z}}{\longleftrightarrow} \mathcal{F}(z)$">|; 

$key = q/k=0,pm1,pm2,ldots,pminfty;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="167" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.gif"
 ALT="$ k=0, \pm 1,
\pm 2, \ldots, \pm\infty$">|; 

$key = q/displaystylemathcal{Y}(z)=2mathcal{X}(z)+frac{1}{2}z^{-1}mathcal{Y}(z).;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="237" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img275.gif"
 ALT="$\displaystyle \mathcal{Y}(z)= 2\mathcal{X}(z) + \frac{1}{2}z^{-1}\mathcal{Y}(z).$">|; 

$key = q/mathcal{X}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img210.gif"
 ALT="$ \mathcal{X}(z)$">|; 

$key = q/t-k<0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="70" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img153.gif"
 ALT="$ t-k&lt;0$">|; 

$key = q/h_{t-k}=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img152.gif"
 ALT="$ h_{t-k}=0$">|; 

$key = q/displaystylea^kstackrel{mathbf{Z}}{longleftrightarrow}frac{1}{1-az^{-1}},quad,kge0,|z|>a;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="302" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img287.gif"
 ALT="$\displaystyle a^k\stackrel{\mathbf{Z}}{\longleftrightarrow} \frac{1}{1-az^{-1}}, \quad, k \ge 0 , \vert z\vert&gt;a$">|; 

$key = q/displaystylesum_{k=0}^{t}x_ky_{t-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img236.gif"
 ALT="$\displaystyle \sum_{k=0}^{t}x_k y_{t-k}$">|; 

$key = q/displaystylemathcal{F}(z)=frac{1}{1-frac{1}{2}z^{-1}},quad|z|>frac{1}{2};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="242" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img86.gif"
 ALT="$\displaystyle \mathcal{F}(z)=\frac{1}{1-\frac{1}{2}z^{-1}}, \quad \vert z\vert&gt;\frac{1}{2}$">|; 

$key = q/displaystylef_k=left{{array}{ll}(-1)^k&kge00&k<0{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="197" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img315.gif"
 ALT="$\displaystyle f_k = \left\{\begin{array}{ll} (-1)^k &amp; k \ge 0 \ 0 &amp; k &lt; 0 \end{array}\right.$">|; 

$key = q/e^{-t}*e^{-t};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img194.gif"
 ALT="$ e^{-t}*e^{-t}$">|; 

$key = q/z=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img14.gif"
 ALT="$ z=0$">|; 

$key = q/infty;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img156.gif"
 ALT="$ \infty$">|; 

$key = q/displaystylew_k;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="28" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img251.gif"
 ALT="$\displaystyle w_k$">|; 

$key = q/n;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img52.gif"
 ALT="$ n$">|; 

$key = q/z^2-1.5z+0.5=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="140" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img298.gif"
 ALT="$ z^2-1.5z+0.5=0$">|; 

$key = q/A_2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img305.gif"
 ALT="$ A_2$">|; 

$key = q/displaystylew_1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img243.gif"
 ALT="$\displaystyle w_1$">|; 

$key = q/displaystylex_kstackrel{mathbf{Z}}{longleftrightarrow}mathcal{X}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="115" HEIGHT="53" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img253.gif"
 ALT="$\displaystyle x_k\stackrel{\mathbf{Z}}{\longleftrightarrow} \mathcal{X}(z)$">|; 

$key = q/displaystylesum_{t=-infty}^{infty}left(sum_{k=-infty}^{infty}x_ky_{t-k}right)z^{-t};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="214" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img216.gif"
 ALT="$\displaystyle \sum_{t=-\infty}^{\infty}
\left(\sum_{k=-\infty}^{\infty}x_k y_{t-k}\right)z^{-t}$">|; 

$key = q/(X*H)*G=X*(H*G);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="201" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img161.gif"
 ALT="$ (X*H)*G = X*(H*G)$">|; 

$key = q/k<0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img151.gif"
 ALT="$ k&lt;0$">|; 

$key = q/z=re^{jomega};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img29.gif"
 ALT="$ z=re^{j\omega}$">|; 

$key = q/displaystyleF(omega)=mathcal{F}(e^{jomega})=sum_{-infty}^{infty}f_ke^{-jkomega};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="255" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.gif"
 ALT="$\displaystyle F(\omega)=\mathcal{F}(e^{j\omega})=\sum_{-\infty}^{\infty}f_ke^{-jk\omega}$">|; 

$key = q/displaystyley_k=left{{array}{ll}1&k=0,10&k=2,3{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="176" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img223.gif"
 ALT="$\displaystyle y_k = \left\{\begin{array}{ll} 1 &amp; k=0,1\ 0 &amp; k=2,3 \end{array}\right.$">|; 

$key = q/Y;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img143.gif"
 ALT="$ Y$">|; 

$key = q/displaystyle(1-3z^{-1}+2z^{-2}+z^{-3})(1+z^{-1});MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="288" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img230.gif"
 ALT="$\displaystyle (1-3z^{-1}+2z^{-2}+z^{-3})(1+z^{-1})$">|; 

$key = q/mathcal{F}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.gif"
 ALT="$ \mathcal{F}(z)$">|; 

$key = q/A_kp^k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img289.gif"
 ALT="$ A_kp^k$">|; 

$key = q/-infty<k<infty;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="104" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img108.gif"
 ALT="$ -\infty &lt;k&lt; \infty$">|; 

$key = q/displaystylee^t*e^t;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img168.gif"
 ALT="$\displaystyle e^t*e^t$">|; 

$key = q/t=-1,0,1,2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img318.gif"
 ALT="$ t=-1,
0,1,2$">|; 

$key = q/displaystylefrac{z}{(z-1)(z-0.5)};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="144" HEIGHT="53" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img302.gif"
 ALT="$\displaystyle \frac{z}{(z-1)(z-0.5)}$">|; 

$key = q/e^{jtheta}-e^{-jtheta}=2jsintheta;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="145" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img132.gif"
 ALT="$ e^{j\theta}-e^{-j\theta} = 2j\sin\theta$">|; 

$key = q/X*H;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img158.gif"
 ALT="$ X*H$">|; 

$key = q/displaystyle=;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.gif"
 ALT="$\displaystyle =$">|; 

$key = q/w_k=x_k*y_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img232.gif"
 ALT="$ w_k=x_k*y_k$">|; 

$key = q/e^{jomega};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="26" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img19.gif"
 ALT="$ e^{j\omega}$">|; 

$key = q/displaystyleleft{{array}{ll}1&k=n0&kneqn{array}right.,quadn>0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="195" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img49.gif"
 ALT="$\displaystyle \left\{\begin{array}{ll}
1 &amp; k=n \\\\
0 &amp; k \neq n
\end{array}\right., \quad n&gt;0$">|; 

$key = q/{figure}center{{epsfig{file=zt_expo_rf.eps,width=3.5in}{{{center{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="402" HEIGHT="323" BORDER="0"
 SRC="|."$dir".q|img83.gif"
 ALT="\begin{figure}\begin{center}
\epsfig{file=zt_expo_rf.eps,width=3.5in}\end{center}\end{figure}">|; 

$key = q/displaystylef_k=left{1,frac{1}{2},left(frac{1}{2}right)^2,left(frac{1}{2}right)^3,ldots,left(frac{1}{2}right)^k,ldotsright},quadkge0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="453" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img82.gif"
 ALT="$\displaystyle f_k = \left\{1, \frac{1}{2}, \left(\frac{1}{2}\right)^2, \left(\f...
...{2}\right)^3, \ldots, \left(\frac{1}{2}\right)^k, \ldots\right\}, \quad k \ge 0$">|; 

$key = q/h_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img137.gif"
 ALT="$ h_k$">|; 

$key = q/displaystylea^kx_kstackrel{mathbf{Z}}{longleftrightarrow}mathcal{X}(a^{-1}z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="164" HEIGHT="53" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img254.gif"
 ALT="$\displaystyle a^kx_k\stackrel{\mathbf{Z}}{\longleftrightarrow} \mathcal{X}(a^{-1}z)$">|; 

$key = q/mathcal{F}(e^{jomega});MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.gif"
 ALT="$ \mathcal{F}(e^{j\omega})$">|; 

$key = q/displaystylew_4;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img249.gif"
 ALT="$\displaystyle w_4$">|; 

$key = q/displaystylesum_{k=-infty}^{infty}delta_{k+n}z^{k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.gif"
 ALT="$\displaystyle \sum_{k=-\infty}^{\infty} \delta_{k+n} z^{k}$">|; 

$key = q/displaystylesum_{k=-infty}^{infty}x_kmathcal{Y}(z)z^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="142" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img219.gif"
 ALT="$\displaystyle \sum_{k=-\infty}^{\infty}x_k \mathcal{Y}(z)z^{-k}$">|; 

$key = q/displaystylemathcal{Y}(z)=(a_0+a_1z^{-tau})mathcal{X}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="220" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img262.gif"
 ALT="$\displaystyle \mathcal{Y}(z)=(a_0+a_1z^{-\tau})\mathcal{X}(z)$">|; 

$key = q/k>3;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img240.gif"
 ALT="$ k&gt;3$">|; 

$key = q/p_N;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img284.gif"
 ALT="$ p_N$">|; 

$key = q/R^kcosktheta;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="69" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img127.gif"
 ALT="$ R^k\cos k\theta$">|; 

$key = q/t=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img265.gif"
 ALT="$ t=0$">|; 

$key = q/displaystyleR^ksin(ktheta),quadkge0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="168" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img123.gif"
 ALT="$\displaystyle R^k\sin(k\theta), \quad k\ge 0$">|; 

$key = q/x_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img136.gif"
 ALT="$ x_k$">|; 

$key = q/displaystylefrac{1-Rcosthetaz^{-1}+jRsinthetaz^{-1}}{[1-Rcosthetaz^{-1}]^2-[jRsinthetaz^{-1}]^2};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="287" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img117.gif"
 ALT="$\displaystyle \frac{1-R\cos\theta z^{-1}+j R\sin\theta z^{-1}}
{[1-R\cos\theta z^{-1}]^2 - [jR\sin\theta z^{-1}]^2}$">|; 

$key = q/f={1,2,5,7,0,1};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="139" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.gif"
 ALT="$ f=\{1,2,5,7,0,1\}$">|; 

$key = q/k=-2,-1,0,1,2,3;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="147" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.gif"
 ALT="$ k=-2,-1,0,1,2,3$">|; 

$key = q/delta_{k-n};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img56.gif"
 ALT="$ \delta_{k-n}$">|; 

$key = q/displaystylex_0y_3+x_1y_2+x_2y_1+x_3y_0=0+0+2+1=3;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="399" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img248.gif"
 ALT="$\displaystyle x_0 y_3+x_1 y_2+x_2 y_1+x_3 y_0=0+0+2+1=3$">|; 

$key = q/e^{jtheta}=costheta+jsintheta;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="140" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img130.gif"
 ALT="$ e^{j\theta} = \cos\theta + j\sin\theta$">|; 

$key = q/z=p_2=0.5;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="92" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img310.gif"
 ALT="$ z = p_2=0.5$">|; 

$key = q/omega;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.gif"
 ALT="$ \omega$">|; 

$key = q/displaystylesum_{k=0}^{t}1(t-k);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img175.gif"
 ALT="$\displaystyle \sum_{k=0}^{t}1 (t-k)$">|; 

$key = q/displaystylefrac{mathcal{Y}(z)}{z};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="66" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img301.gif"
 ALT="$\displaystyle \frac{\mathcal{Y}(z)}{z}$">|; 

$key = q/*;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img141.gif"
 ALT="$ *$">|; 

$key = q/displaystyleRe{f_k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img120.gif"
 ALT="$\displaystyle \Re{f_k}$">|; 

$key = q/e^{-jpislash2}=-j;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="89" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img134.gif"
 ALT="$ e^{-j\pi/2}=-j$">|; 

$key = q/y_t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img138.gif"
 ALT="$ y_t$">|; 

$key = q/n_h-1leqtleqn_x;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="118" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img191.gif"
 ALT="$ n_h-1 \leq t \leq n_x$">|; 

$key = q/displaystyle{x_0,x_1,x_2,ldots,x_k,ldots,x_{t-2},x_{t-1},x_{t}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="313" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img181.gif"
 ALT="$\displaystyle \{x_0, x_1, x_2, \ldots, x_k, \ldots, x_{t-2}, x_{t-1}, x_{t}\}$">|; 

$key = q/z^{-t};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img217.gif"
 ALT="$ z^{-t}$">|; 

$key = q/displaystyle0,quadk>4;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img252.gif"
 ALT="$\displaystyle 0, \quad k&gt;4$">|; 

$key = q/a_1x_k+a_2y_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img197.gif"
 ALT="$ a_1x_k+a_2y_k$">|; 

$key = q/t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="10" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img139.gif"
 ALT="$ t$">|; 

$key = q/displaystyle1+z^{-1};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="68" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img228.gif"
 ALT="$\displaystyle 1+z^{-1}$">|; 

$key = q/displaystylefrac{1}{1-Rcosthetaz^{-1}-jRsinthetaz^{-1}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="249" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img116.gif"
 ALT="$\displaystyle \frac{1}{1-R\cos\theta z^{-1}-j R\sin\theta z^{-1}}$">|; 

$key = q/t=0,1,2,3;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="87" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img320.gif"
 ALT="$ t=0, 1,2,3$">|; 

$key = q/displaystylef_k;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.gif"
 ALT="$\displaystyle f_k$">|; 

$key = q/displaystyle(y_k)_n=A_np_n^k+A^*_n(p^*_n)^k,quadkge0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="286" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img294.gif"
 ALT="$\displaystyle (y_k)_n = A_np_n^k + A^*_n(p^*_n)^k, \quad k \ge 0$">|; 

$key = q/displaystylemathcal{Y}(z)=frac{A_1}{1-p_1z^{-1}}+frac{A_2}{1-p_2z^{-1}}+ldots+frac{A_N}{1-p_Nz^{-1}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="429" HEIGHT="63" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img285.gif"
 ALT="$\displaystyle \mathcal{Y}(z)= \frac{A_1}{1-p_1z^{-1}}+\frac{A_2}{1-p_2z^{-1}}+\ldots + \frac{A_N}{1-p_Nz^{-1}}$">|; 

$key = q/|alpha|;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img79.gif"
 ALT="$ \vert\alpha\vert$">|; 

$key = q/u_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img93.gif"
 ALT="$ u_k$">|; 

$key = q/0<omegalepi;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img109.gif"
 ALT="$ 0&lt;\omega\le\pi$">|; 

$key = q/p_j^*;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img293.gif"
 ALT="$ p_j^*$">|; 

$key = q/H(omega);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img272.gif"
 ALT="$ H(\omega)$">|; 

$key = q/displaystylemathcal{H}(z)=a_0+a_1z^{-tau};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="164" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img263.gif"
 ALT="$\displaystyle \mathcal{H}(z)=a_0+a_1z^{-\tau}$">|; 

$key = q/displaystylemathcal{F}(z)equivmathbf{Z}[f_k];MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="117" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.gif"
 ALT="$\displaystyle \mathcal{F}(z) \equiv \mathbf{Z}[f_k]$">|; 

$key = q/displaystyleh_t=2left(frac{1}{2}right)^k,quadkge0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="194" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img279.gif"
 ALT="$\displaystyle h_t = 2\left(\frac{1}{2}\right)^k, \quad k\ge 0$">|; 

$key = q/z=1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img95.gif"
 ALT="$ z=1$">|; 

$key = q/e^{jomegaslash2}-e^{-jomegaslash2}=2jsinomegaslash2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="192" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img129.gif"
 ALT="$ e^{j\omega/2}-e^{-j\omega/2} =
2j\sin\omega/2$">|; 

$key = q/k>n_x-1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="81" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img189.gif"
 ALT="$ k&gt;n_x-1$">|; 

$key = q/Z^{-1}{cdot};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img195.gif"
 ALT="$ Z^{-1}\{\cdot\}$">|; 

$key = q/displaystyle1z^{-n}=z^{-n}=frac{1}{z^n};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="152" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img55.gif"
 ALT="$\displaystyle 1z^{-n}=z^{-n}=\frac{1}{z^n}$">|; 

$key = q/X(omega);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img270.gif"
 ALT="$ X(\omega)$">|; 

$key = q/displaystyledelta_{k+n};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.gif"
 ALT="$\displaystyle \delta_{k+n}$">|; 

$key = q/displaystyle|a|<1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img72.gif"
 ALT="$\displaystyle \vert a\vert&lt;1$">|; 

$key = q/(z-1)(z-0.5);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="116" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img306.gif"
 ALT="$ (z-1)(z-0.5)$">|; 

$key = q/delta_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img61.gif"
 ALT="$ \delta_k$">|; 

$key = q/{algorithm}%latex2htmlidmarker531{caption{Discreteconvolution.}{algorithmic{REQU_kh'_k{STATE{y_t=sum_{k=0}^ts_k{ENDFORalgorithmic{{algorithm};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="654" HEIGHT="185" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img184.gif"
 ALT="\begin{algorithm}
% latex2html id marker 531\caption{Discrete convolution.
}\b...
..._k h'_k$ \STATE $y_t = \sum_{k=0}^t s_k$\ENDFOR
\end{algorithmic}\end{algorithm}">|; 

$key = q/displaystylew_t;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="25" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img235.gif"
 ALT="$\displaystyle w_t$">|; 

$key = q/vec{1}*vec{1};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="18" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img164.gif"
 ALT="$ \vec{1}*\vec{1}$">|; 

$key = q/displaystyle1+a+a^2+a^3+ldots=frac{1}{1-a},;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="262" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img71.gif"
 ALT="$\displaystyle 1+a+a^2+a^3+\ldots = \frac{1}{1-a},$">|; 

$key = q/displaystylemathcal{Y}(z)=mathcal{H}(z)mathcal{X}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="157" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img264.gif"
 ALT="$\displaystyle \mathcal{Y}(z)=\mathcal{H}(z)\mathcal{X}(z)$">|; 

$key = q/displaystylemathcal{Y}(z)=mathcal{X}(z)mathcal{H}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="157" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img259.gif"
 ALT="$\displaystyle \mathcal{Y}(z) =\mathcal{X}(z)\mathcal{H}(z)$">|; 

$key = q/displaystylemathcal{Y}(z)=a_0mathcal{X}(z)+a_1z^{-tau}mathcal{X}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="248" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img261.gif"
 ALT="$\displaystyle \mathcal{Y}(z)=a_0\mathcal{X}(z)+a_1z^{-\tau}\mathcal{X}(z)$">|; 

$key = q/e^{-jtheta}=cos(-theta)+jsin(-theta)=costheta-jsintheta;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="313" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img131.gif"
 ALT="$ e^{-j\theta} = \cos(-\theta) + j\sin(-\theta)
= \cos\theta - j\sin\theta$">|; 

$key = q/t<n_h-1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img187.gif"
 ALT="$ t&lt;n_h-1$">|; 

$key = q/ldots;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img283.gif"
 ALT="$ \ldots$">|; 

$key = q/displaystylex_0y_0=1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img242.gif"
 ALT="$\displaystyle x_0 y_0 = 1$">|; 

$key = q/mathcal{X}(z)mathcal{Y}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="73" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img208.gif"
 ALT="$ \mathcal{X}(z)\mathcal{Y}(z)$">|; 

$key = q/r=1slash2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="59" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.gif"
 ALT="$ r=1/2$">|; 

$key = q/displaystylesum_{k=0}^{t}e^t=e^tsum_{k=0}^{t}1=te^t;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img170.gif"
 ALT="$\displaystyle \sum_{k=0}^{t}e^t=e^t\sum_{k=0}^{t}1=te^t$">|; 

$key = q/p_1=1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img299.gif"
 ALT="$ p_1=1$">|; 

$key = q/|z|>|alpha|;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img77.gif"
 ALT="$ \vert z\vert&gt;\vert\alpha\vert$">|; 

$key = q/displaystylex_1y_3+x_2y_2+x_3y_1=0+0+1=1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="304" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img250.gif"
 ALT="$\displaystyle x_1 y_3+x_2 y_2+x_3 y_1 =0+0+1=1$">|; 

$key = q/X*(H1+H2)=X*H1+X*H2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="264" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img160.gif"
 ALT="$ X*(H1+H2)=X*H1 + X*H2$">|; 

$key = q/y_k=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img239.gif"
 ALT="$ y_k=0$">|; 

$key = q/displaystyle1-2z^{-1}-z^{-2}+3z^{-3}+z^{-4};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="248" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img231.gif"
 ALT="$\displaystyle 1-2z^{-1}-z^{-2}+3z^{-3}+z^{-4}$">|; 

$key = q/displaystyledelta_{k-n}stackrel{mathbf{Z}}{longleftrightarrow}1*z^{-n}=z^{-n};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="206" HEIGHT="53" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img221.gif"
 ALT="$\displaystyle \delta_{k-n}\stackrel{\mathbf{Z}}{\longleftrightarrow} 1*z^{-n}=z^{-n}$">|; 

$key = q/k=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.gif"
 ALT="$ k=0$">|; 

$key = q/pi;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.gif"
 ALT="$ \pi$">|; 

$key = q/z;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.gif"
 ALT="$ z$">|; 

$key = q/A_1,A_2,ldots,A_N;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="110" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img286.gif"
 ALT="$ A_1, A_2, \ldots, A_N$">|; 

$key = q/displaystyleR^kcos(ktheta)stackrel{mathbf{Z}}{longleftrightarrow}frac{1-Rcosthetaz^{-1}}{1-2Rcosthetaz^{-1}+R^2z^{-2}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="359" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img124.gif"
 ALT="$\displaystyle R^k\cos(k\theta)\stackrel{\mathbf{Z}}{\longleftrightarrow}  \frac{1-R\cos\theta z^{-1}} {1-2R\cos\theta z^{-1} + R^2 z^{-2}}$">|; 

$key = q/displaystylex_0y_{t}+x_1y_{t-1}+x_2y_{t-2}+x_3y_{t-3};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="271" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img237.gif"
 ALT="$\displaystyle x_0 y_{t}+x_1 y_{t-1}+x_2 y_{t-2}+x_3 y_{t-3}$">|; 

$key = q/|z|=1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img96.gif"
 ALT="$ \vert z\vert=1$">|; 

$key = q/Nrightarrowinfty;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="62" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img73.gif"
 ALT="$ N \rightarrow \infty$">|; 

$key = q/displaystyleu_0*H;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img174.gif"
 ALT="$\displaystyle u_0*H$">|; 

$key = q/displaystylefrac{e^{jomegaslash2}}{e^{jomegaslash2}-e^{-jomegaslash2}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="70" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img100.gif"
 ALT="$\displaystyle \frac{e^{j\omega/2}}{e^{j\omega/2}-e^{-j\omega/2}}$">|; 

$key = q/{figure}center{{epsfig{file=zt_conv_etet.eps,width=4in}{{{center{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="460" HEIGHT="583" BORDER="0"
 SRC="|."$dir".q|img192.gif"
 ALT="\begin{figure}\begin{center}
\epsfig{file=zt_conv_etet.eps,width=4in}\end{center}\end{figure}">|; 

$key = q/alpha;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img67.gif"
 ALT="$ \alpha$">|; 

$key = q/a^Nrightarrow0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="58" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img75.gif"
 ALT="$ a^N \rightarrow 0$">|; 

$key = q/x_{-k};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img203.gif"
 ALT="$ x_{-k}$">|; 

$key = q/displaystylesum_{k=0}^{infty}alpha^kz^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="88" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img69.gif"
 ALT="$\displaystyle \sum_{k=0}^{\infty}\alpha^k z^{-k}$">|; 

$key = q/{figure}center{textbf{{itshape{Figuretobefaxed.}center{{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="148" HEIGHT="18" BORDER="0"
 SRC="|."$dir".q|img185.gif"
 ALT="\begin{figure}\begin{center}
\textbf{\itshape Figure to be faxed.}
\end{center}\end{figure}">|; 

$key = q/displaystyleu_0*u_0=sum_{k=0}^{t}1=t;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="164" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img179.gif"
 ALT="$\displaystyle u_0*u_0=\sum_{k=0}^{t}1=t$">|; 

$key = q/displaystylefrac{1-Rcosthetaz^{-1}+jRsinthetaz^{-1}}{1-2Rcosthetaz^{-1}+R^2z^{-2}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="249" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img118.gif"
 ALT="$\displaystyle \frac{1-R\cos\theta z^{-1}+j R\sin\theta z^{-1}}
{1-2R\cos\theta z^{-1} + R^2 z^{-2}}$">|; 

$key = q/displaystylefrac{e^{jomegaslash2}}{2jsinomegaslash2};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="92" HEIGHT="70" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img101.gif"
 ALT="$\displaystyle \frac{e^{j\omega/2}}{2j\sin\omega/2}$">|; 

$key = q/displaystyley_t=sum_{k=0}^{t}x_kh_{t-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img154.gif"
 ALT="$\displaystyle y_t = \sum_{k=0}^{t}x_k h_{t-k}$">|; 

$key = q/displaystylew_0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img241.gif"
 ALT="$\displaystyle w_0$">|; 

$key = q/displaystyle|F(omega)|=|mathcal{F}(e^{jomega})|=|e^{-jn}|=1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="265" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img60.gif"
 ALT="$\displaystyle \vert F(\omega)\vert=\vert\mathcal{F}(e^{j\omega})\vert=\vert e^{-jn}\vert=1$">|; 

$key = q/displaystyle|F(omega)|=|mathcal{F}(e^{jomega})|=left|frac{1}{1-frac{1}{2}e^{-jomega}}right|;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="281" HEIGHT="66" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img87.gif"
 ALT="$\displaystyle \vert F(\omega)\vert=\vert\mathcal{F}(e^{j\omega})\vert =\left\vert\frac{1}{1-\frac{1}{2}e^{-j\omega}}\right\vert$">|; 

$key = q/displaystylemathcal{F}(z)=frac{1}{1-Re^{jtheta}z^{-1}},quad|z|>|R|;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="282" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img112.gif"
 ALT="$\displaystyle \mathcal{F}(z)=\frac{1}{1-Re^{j\theta}z^{-1}}, \quad \vert z\vert&gt;\vert R\vert$">|; 

$key = q/-n;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img53.gif"
 ALT="$ -n$">|; 

$key = q/displaystyley_t=x_0h_t+x_1h_{t-1}+x_2h_{t-2}+ldots+x_kh_{t-k}+ldots+x_{t-2}h_{2}+x_{t-1}h_{1}+x_{t}h_0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="634" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img157.gif"
 ALT="$\displaystyle y_t = x_0 h_t+x_1 h_{t-1}+x_2 h_{t-2}+\ldots+x_k h_{t-k} +\ldots+x_{t-2}h_{2}+x_{t-1}h_{1}+x_{t}h_0$">|; 

$key = q/displaystylemathcal{H}(z)=frac{mathcal{Y}(z)}{mathcal{X}(z)}=frac{2}{1-frac{1}{2}z^{-1}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="226" HEIGHT="66" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img276.gif"
 ALT="$\displaystyle \mathcal{H}(z)=\frac{\mathcal{Y}(z)}{\mathcal{X}(z)}= \frac{2}{1-\frac{1}{2}z^{-1}}$">|; 

$key = q/R<1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img126.gif"
 ALT="$ R&lt;1$">|; 

$key = q/z=^{jomega};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img268.gif"
 ALT="$ z=^{j\omega}$">|; 

$key = q/z^{-n}mathcal{X}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="65" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img200.gif"
 ALT="$ z^{-n}\mathcal{X}(z)$">|; 

$key = q/-zensuremath{frac{mathrm{d}mathcal{X}(z)}{mathrm{d}z}};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img206.gif"
 ALT="$ -z \ensuremath{\frac{\mathrm{d} \mathcal{X}(z)}{\mathrm{d} z}}$">|; 

$key = q/displaystylefrac{1}{j2pi}int_{-pi}^{pi}F(omega)e^{j(k-1)omega}je^{jomega}domega;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="243" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.gif"
 ALT="$\displaystyle \frac{1}{j2\pi}\int_{-\pi}^{\pi} F(\omega)
e^{j(k-1)\omega}je^{j\omega}d\omega$">|; 

$key = q/z=Re^{jtheta};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img113.gif"
 ALT="$ z=Re^{j\theta}$">|; 

$key = q/displaystyley_k=A_1p_1^k+A_2p_2^k+ldots+A_Np_N^k,quad,kge0;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="365" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img291.gif"
 ALT="$\displaystyle y_k = A_1p_1^k + A_2p_2^k +\ldots + A_Np_N^k , \quad, k \ge 0$">|; 

$key = q/vec{1}=u_0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img166.gif"
 ALT="$ \vec{1}=u_0$">|; 

$key = q/displaystylesum_{k=-infty}^{infty}x_k(a^{-1}z)^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="147" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img256.gif"
 ALT="$\displaystyle \sum_{k=-\infty}^{\infty}x_k(a^{-1}z)^{-k}$">|; 

$key = q/|F(omega)|rightarrowinfty;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img105.gif"
 ALT="$ \vert F(\omega)\vert\rightarrow \infty$">|; 

$key = q/alpha=Re^{jtheta};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="69" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img110.gif"
 ALT="$ \alpha=Re^{j\theta}$">|; 

$key = q/displaystyledelta_k=left{{array}{ll}1&k=00&kneq0{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="156" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.gif"
 ALT="$\displaystyle \delta_k = \left\{\begin{array}{ll} 1 &amp; k=0 \ 0 &amp; k \neq 0 \end{array}\right.$">|; 

$key = q/displaystylemathcal{Y}(z)=frac{2}{(1-z^{-1})}-frac{1}{(1-0.5z^{-1})};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="287" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img313.gif"
 ALT="$\displaystyle \mathcal{Y}(z) = \frac{2}{(1-z^{-1})} - \frac{1}{(1-0.5z^{-1})}$">|; 

$key = q/mathcal{Y}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img211.gif"
 ALT="$ \mathcal{Y}(z)$">|; 

$key = q/displaystylew_3;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img247.gif"
 ALT="$\displaystyle w_3$">|; 

$key = q/p_j;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img292.gif"
 ALT="$ p_j$">|; 

$key = q/displaystyle1z^{-0}=1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.gif"
 ALT="$\displaystyle 1z^{-0}=1$">|; 

$key = q/displaystylex_k=left{{array}{ll}cosomega_0k&kge00&k<0{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="210" HEIGHT="67" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img316.gif"
 ALT="$\displaystyle x_k = \left\{\begin{array}{ll} \cos\omega_0k &amp; k \ge 0 \ 0 &amp; k &lt; 0 \end{array}\right.$">|; 

$key = q/1slash2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="29" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img85.gif"
 ALT="$ 1/2$">|; 

$key = q/y_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img209.gif"
 ALT="$ y_k$">|; 

$key = q/-pi;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.gif"
 ALT="$ -\pi$">|; 

$key = q/kge0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img290.gif"
 ALT="$ k\ge 0$">|; 

$key = q/k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img92.gif"
 ALT="$ k$">|; 

$key = q/x_t={1,2,3,1};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img319.gif"
 ALT="$ x_t=\{1,2,3,1\}$">|; 

$key = q/a^kx_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img201.gif"
 ALT="$ a^kx_k$">|; 

$key = q/kx_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img205.gif"
 ALT="$ kx_k$">|; 

$key = q/f_k;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.gif"
 ALT="$ f_k$">|; 

$key = q/X*H=H*X;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="117" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img159.gif"
 ALT="$ X*H=H*X$">|; 

$key = q/displaystylesum_{k=0}^{t}t-sum_{k=0}^{t}k;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="112" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img176.gif"
 ALT="$\displaystyle \sum_{k=0}^{t}t -\sum_{k=0}^{t} k$">|; 

$key = q/t>nx-1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img188.gif"
 ALT="$ t&gt;nx-1$">|; 

$key = q/n_x=5;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.gif"
 ALT="$ n_x=5$">|; 

$key = q/displaystylemathcal{F}(e^{jomega})=frac{1}{1-e^{-jomega}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="164" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img99.gif"
 ALT="$\displaystyle \mathcal{F}(e^{j\omega})=\frac{1}{1-e^{-j\omega}}$">|; 

$key = q/z=infty;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img39.gif"
 ALT="$ z=\infty$">|; 

$key = q/displaystylemathcal{Y}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img227.gif"
 ALT="$\displaystyle \mathcal{Y}(z)$">|; 

$key = q/delta_{k+n};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img62.gif"
 ALT="$ \delta_{k+n}$">|; 

$key = q/h_t={1,2,1,-1};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="125" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img317.gif"
 ALT="$ h_t=\{1,2,1,-1\}$">|; 

$key = q/displaystyley_t=a_0x_t+a_1x_{t-tau};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img260.gif"
 ALT="$\displaystyle y_t=a_0x_t+a_1x_{t-\tau}$">|; 

$key = q/u_0*u_0neu_0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img180.gif"
 ALT="$ u_0*u_0 \ne u_0$">|; 

$key = q/w_t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img213.gif"
 ALT="$ w_t$">|; 

$key = q/h_t=t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img172.gif"
 ALT="$ h_t = t$">|; 

$key = q/W=X*Y;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="88" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img224.gif"
 ALT="$ W = X*Y$">|; 

$key = q/displaystyleZleft{a^kx_kright}=sum_{k=-infty}^{infty}a^kx_kz^{-k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="228" HEIGHT="74" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img255.gif"
 ALT="$\displaystyle Z\left\{a^kx_k\right\} = \sum_{k=-\infty}^{\infty} a^kx_kz^{-k}$">|; 

$key = q/u_0*HneH;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="88" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img171.gif"
 ALT="$ u_0*H \ne H$">|; 

$key = q/displaystylef_k=left{{array}{ll}frac{1}{2}^k&quadkge00&quadk<0{array}right.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="188" HEIGHT="70" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img81.gif"
 ALT="$\displaystyle f_k = \left\{\begin{array}{ll} \frac{1}{2}^k &amp; \quad k \ge 0 \ 0 &amp; \quad k &lt; 0 \end{array}\right.$">|; 

$key = q/k=0,1,2,3,4,5;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="121" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.gif"
 ALT="$ k=0,1,2,3,4,5$">|; 

$key = q/mathcal{W}(z);MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img233.gif"
 ALT="$ \mathcal{W}(z)$">|; 

$key = q/de^{jomega}=je^{jomega}domega;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="105" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.gif"
 ALT="$ de^{j\omega} = je^{j\omega}d\omega$">|; 

$key = q/x_{k-n};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="37" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img199.gif"
 ALT="$ x_{k-n}$">|; 

$key = q/n_h<n_x;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img186.gif"
 ALT="$ n_h &lt; n_x$">|; 

$key = q/displaystyle|F(omega)|=|mathcal{F}(e^{jomega})|=1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="191" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img47.gif"
 ALT="$\displaystyle \vert F(\omega)\vert=\vert\mathcal{F}(e^{j\omega})\vert=1$">|; 

$key = q/|z|>1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img97.gif"
 ALT="$ \vert z\vert&gt;1$">|; 

$key = q/displaystylemathcal{X}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="48" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img225.gif"
 ALT="$\displaystyle \mathcal{X}(z)$">|; 

$key = q/displaystyle{h_t,h_{t-1},h_{t-2},ldots,h_{t-k},ldots,h_2,h_1,h_0};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="331" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img182.gif"
 ALT="$\displaystyle \{h_t, h_{t-1}, h_{t-2}, \ldots, h_{t-k} , \ldots, h_2, h_1, h_0\}$">|; 

$key = q/omegarightarrow0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img106.gif"
 ALT="$ \omega\rightarrow 0$">|; 

$key = q/vec{0};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img163.gif"
 ALT="$ \vec{0}$">|; 

$key = q/R^ksinktheta;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img128.gif"
 ALT="$ R^k\sin k\theta$">|; 

$key = q/displaystyley_k=2(1)^k-(0.5)^k=2-0.5^k,quadkge0,;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="343" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img314.gif"
 ALT="$\displaystyle y_k = 2(1)^k -(0.5)^k = 2-0.5^k, \quad k\ge 0,$">|; 

$key = q/displaystyle1=A_1(1-0.5)longrightarrowA_1=2;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="241" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img309.gif"
 ALT="$\displaystyle 1= A_1(1-0.5) \longrightarrow A_1 = 2$">|; 

$key = q/displaystylemathcal{F}(z)=1z^2+2z+5+7z^{-1}+z^{-3};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="295" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img38.gif"
 ALT="$\displaystyle \mathcal{F}(z)=1z^2+2z+5+7z^{-1}+z^{-3}$">|; 

$key = q/displaystylemathcal{Y}(z)=frac{1}{1-1.5z^{-1}+0.5z^{-2}};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="243" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img295.gif"
 ALT="$\displaystyle \mathcal{Y}(z) = \frac{1}{1-1.5z^{-1}+0.5z^{-2}}$">|; 

$key = q/displaystyleIm{f_k};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img122.gif"
 ALT="$\displaystyle \Im{f_k}$">|; 

$key = q/t=0,1,2,ldots;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="98" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img173.gif"
 ALT="$ t=0,1,2,\ldots$">|; 

$key = q/zneq0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img58.gif"
 ALT="$ z \neq 0$">|; 

$key = q/displaystylew_k=x_k*y_k={1,-2,-1,3,1};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="273" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img234.gif"
 ALT="$\displaystyle w_k=x_k*y_k = \{1,-2, -1, 3, 1\}$">|; 

$key = q/displaystylefrac{1}{2pi}int_{-pi}^{pi}F(omega)e^{jkomega}domega;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img27.gif"
 ALT="$\displaystyle \frac{1}{2\pi}\int_{-\pi}^{\pi} F(\omega)e^{jk\omega}d\omega$">|; 

$key = q/displaystylemathcal{X}(a^{-1}z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="77" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img257.gif"
 ALT="$\displaystyle \mathcal{X}(a^{-1}z)$">|; 

$key = q/-infty;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img155.gif"
 ALT="$ -\infty$">|; 

$key = q/e^t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.gif"
 ALT="$ e^t$">|; 

$key = q/displaystyle0.5=A_2(0.5-1)longrightarrowA_2=-1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="272" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img311.gif"
 ALT="$\displaystyle 0.5= A_2(0.5-1) \longrightarrow A_2 = -1$">|; 

$key = q/e^t*e^t;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.gif"
 ALT="$ e^t*e^t$">|; 

$key = q/x*vec{0}=vec{0}*x=0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="123" HEIGHT="19" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img162.gif"
 ALT="$ x*\vec{0} = \vec{0}*x = 0$">|; 

$key = q/p_1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img281.gif"
 ALT="$ p_1$">|; 

$key = q/displaystylemathcal{W}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img214.gif"
 ALT="$\displaystyle \mathcal{W}(z)$">|; 

$key = q/{figure}center{{epsfig{file=zt_expo_r1F.eps,width=3.5in}{{{center{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="402" HEIGHT="321" BORDER="0"
 SRC="|."$dir".q|img107.gif"
 ALT="\begin{figure}\begin{center}
\epsfig{file=zt_expo_r1F.eps,width=3.5in}\end{center}\end{figure}">|; 

$key = q/|a|<1;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img74.gif"
 ALT="$ \vert a\vert&lt;1$">|; 

$key = q/theta=omegaslash2;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="61" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img133.gif"
 ALT="$ \theta=\omega/2$">|; 

$key = q/z^{-n};MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="30" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img57.gif"
 ALT="$ z^{-n}$">|; 

$key = q/displaystylemathcal{F}(z)=frac{1}{1-z^{-1}},quad|z|>1;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="227" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img94.gif"
 ALT="$\displaystyle \mathcal{F}(z)=\frac{1}{1-z^{-1}}, \quad \vert z\vert&gt;1$">|; 

$key = q/displaystylemathcal{F}(z);MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="47" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img43.gif"
 ALT="$\displaystyle \mathcal{F}(z)$">|; 

$key = q/u_0*u_0;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img178.gif"
 ALT="$ u_0*u_0$">|; 

$key = q/displaystyle1-3z^{-1}+2z^{-2}+z^{-3};MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="195" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img226.gif"
 ALT="$\displaystyle 1-3z^{-1}+2z^{-2}+z^{-3}$">|; 

$key = q/f_k=(1slash2)^k,k=0,1,2,ldots;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="190" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.gif"
 ALT="$ f_k=(1/2)^k, k=0,1,2,\ldots $">|; 

$key = q/|F(omega)|;MSF=1.4;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img63.gif"
 ALT="$ \vert F(\omega)\vert$">|; 

$key = q/displaystyley_t=sum_{k=0}^{t}delta_kh_{t-k}=h_t;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="177" HEIGHT="79" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img266.gif"
 ALT="$\displaystyle y_t=\sum_{k=0}^{t}\delta_k h_{t-k}=h_t$">|; 

$key = q/displaystyley_t=2x_t+frac{1}{2}y_{t-1}.;MSF=1.4;LFS=12;DSF=1.2;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="151" HEIGHT="61" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img273.gif"
 ALT="$\displaystyle y_t = 2x_t + \frac{1}{2}y_{t-1}.$">|; 

1;

