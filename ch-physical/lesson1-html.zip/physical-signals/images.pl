# LaTeX2HTML 2K.1beta (1.50)
# Associate images original text with physical files.


$key = q/2Lslashc;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img125.gif"
 ALT="$ 2L/c$">|; 

$key = q/displaystylea_1e^{jomegat}+a_2e^{j(omega+delta)t};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="149" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img92.gif"
 ALT="$\displaystyle a_1 e^{j\omega t} + a_2 e^{j(\omega+\delta)t}$">|; 

$key = q/sqrt{-1};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img47.gif"
 ALT="$ \sqrt{-1}$">|; 

$key = q/|z|^2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="33" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img87.gif"
 ALT="$ \vert z\vert^2$">|; 

$key = q/displaystyley(x,0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="58" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img135.gif"
 ALT="$\displaystyle y(x,0)$">|; 

$key = q/(x+v)+j(y+w);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="156" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img52.gif"
 ALT="$ (x+v) + j (y+w)$">|; 

$key = q/displaystyleensuremath{frac{mathrm{d}^{2}}{mathrm{d}t^{2}}}sinomegat=ensuremath{frac{mathrm{d}}{mathrm{d}t}}omegacosomegat=-omega^2sinomegat;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="304" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.gif"
 ALT="$\displaystyle \ensuremath{\frac{\mathrm{d}^{2} }{\mathrm{d} t^{2}}}\sin\omega t...
...h{\frac{\mathrm{d} }{\mathrm{d} t}}\omega\cos\omega t = -\omega^2 \sin\omega t$">|; 

$key = q/m;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img12.gif"
 ALT="$ m$">|; 

$key = q/P;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img110.gif"
 ALT="$ P$">|; 

$key = q/a_1+a_2e^{jdeltat};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img95.gif"
 ALT="$ a_1 + a_2 e^{j\delta t}$">|; 

$key = q/phi_1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img38.gif"
 ALT="$ \phi_1$">|; 

$key = q/j^2=-1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img54.gif"
 ALT="$ j^2 = -1$">|; 

$key = q/displaystylet;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img102.gif"
 ALT="$\displaystyle t$">|; 

$key = q/displaystylesum_{k=1}^inftyc_ke^{jkomega_0cdot0}sin(kpixslashL);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="196" HEIGHT="70" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img136.gif"
 ALT="$\displaystyle \sum_{k=1}^\infty c_k e^{jk\omega_0 \cdot 0} \sin(k\pi x/L)$">|; 

$key = q/k^{textrmth};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img73.gif"
 ALT="$ k^{\textrm th}$">|; 

$key = q/z=Re^{jtheta};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="76" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img80.gif"
 ALT="$ z=Re^{j\theta}$">|; 

$key = q/x=0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img14.gif"
 ALT="$ x=0$">|; 

$key = q/displaystylex(t)=sin(omegat+phi);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img30.gif"
 ALT="$\displaystyle x(t) = \sin(\omega t + \phi)$">|; 

$key = q/displaystylee^{jtheta(t)}=e^{jomegat};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="43" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img89.gif"
 ALT="$\displaystyle e^{j\theta(t)} = e^{j\omega t}$">|; 

$key = q/sinomegat;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="50" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img23.gif"
 ALT="$ \sin\omega t$">|; 

$key = q/displaystyleje^{jtheta};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img70.gif"
 ALT="$\displaystyle je^{j\theta}$">|; 

$key = q/a=mathrm{d}vslashmathrm{d}t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="86" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.gif"
 ALT="$ a = \mathrm{d}v/\mathrm{d}t$">|; 

$key = q/a_1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img36.gif"
 ALT="$ a_1$">|; 

$key = q/displaystyleensuremath{frac{partial(2x^2t+3t^3x)}{partialx}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img105.gif"
 ALT="$\displaystyle \ensuremath{\frac{\partial (2x^2t + 3t^3x)}{\partial x}}$">|; 

$key = q/{figure}vspace{2in}textit{{bfseries{GetsketchfromMike.}{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="172" HEIGHT="18" BORDER="0"
 SRC="|."$dir".q|img5.gif"
 ALT="\begin{figure}\vspace{2in}
\textit{\bfseries Get sketch from Mike.}
\end{figure}">|; 

$key = q/displaystyleensuremath{frac{mathrm{d}^{2}x}{mathrm{d}t^{2}}}=-frac{k}{m}x;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.gif"
 ALT="$\displaystyle \ensuremath{\frac{\mathrm{d}^{2} x}{\mathrm{d} t^{2}}}= -\frac{k}{m} x$">|; 

$key = q/R_1R_2angle(theta_1+theta_2);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="129" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img60.gif"
 ALT="$ R_1R_2\angle(\theta_1+\theta_2)$">|; 

$key = q/x;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.gif"
 ALT="$ x$">|; 

$key = q/z^*=Re^{-jtheta};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img81.gif"
 ALT="$ z^* =
Re^{-j\theta}$">|; 

$key = q/theta(t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="35" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img40.gif"
 ALT="$ \theta(t)$">|; 

$key = q/mathbf{v};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="16" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img43.gif"
 ALT="$ \mathbf{v}$">|; 

$key = q/f(cdot);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="36" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img117.gif"
 ALT="$ f(\cdot)$">|; 

$key = q/2Real(z);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="63" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img83.gif"
 ALT="$ 2\Real(z)$">|; 

$key = q/cosomegat;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img24.gif"
 ALT="$ \cos\omega t$">|; 

$key = q/v+jw;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img51.gif"
 ALT="$ v +
jw$">|; 

$key = q/displaystylef(t)=f(t-2Lslashc);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="158" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img124.gif"
 ALT="$\displaystyle f(t) = f(t -2L/c)$">|; 

$key = q/c;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img114.gif"
 ALT="$ c$">|; 

$key = q/displaystyle=;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img67.gif"
 ALT="$\displaystyle =$">|; 

$key = q/displaystyleE(theta)^k=left(e^{jtheta}right)^k=e^{jtheta}e^{jtheta}cdotse^{jtheta}=e^{jktheta};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="301" HEIGHT="49" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img72.gif"
 ALT="$\displaystyle E(\theta)^k = \left( e^{j\theta} \right) ^k = e^{j\theta} e^{j\theta} \cdots e^{j\theta} = e^{jk\theta}$">|; 

$key = q/displaystyle4xt+3t^3;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="78" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img106.gif"
 ALT="$\displaystyle 4xt + 3t^3$">|; 

$key = q/z_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img76.gif"
 ALT="$ z_2$">|; 

$key = q/k;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img17.gif"
 ALT="$ k$">|; 

$key = q/displaystyleensuremath{frac{mathrm{d}}{mathrm{d}t}}E(theta)=-sintheta+jcostheta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="215" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img64.gif"
 ALT="$\displaystyle \ensuremath{\frac{\mathrm{d} }{\mathrm{d} t}}E(\theta) = -\sin\theta + j\cos\theta$">|; 

$key = q/{window}[0,r,<comment_mark>18{{fbox{parbox{0.4textwidth}{smalltextbf{RequiredRear,andcentraltotheuserishowhisorhersensorysystemworks.{window};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="745" HEIGHT="617" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.gif"
 ALT="\begin{window}[0,r,%%
{\fbox{\parbox{0.4\textwidth}{\small \textbf{Required Read...
...er, and central to the user is how his or her sensory
system works.
\end{window}">|; 

$key = q/c^2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="20" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img113.gif"
 ALT="$ c^2$">|; 

$key = q/displaystyleE(theta);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img66.gif"
 ALT="$\displaystyle E(\theta)$">|; 

$key = q/displaystyleensuremath{frac{mathrm{d}}{mathrm{d}t}}sinomegat=omegacosomegat;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="162" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img25.gif"
 ALT="$\displaystyle \ensuremath{\frac{\mathrm{d} }{\mathrm{d} t}}\sin\omega t = \omega\cos\omega t$">|; 

$key = q/displaystyleensuremath{frac{partial(xt)}{partialx}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="62" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img101.gif"
 ALT="$\displaystyle \ensuremath{\frac{\partial (xt)}{\partial x}}$">|; 

$key = q/displaystyleensuremath{frac{partial^2y}{partialt^{2}}}=c^2ensuremath{frac{partial^2y}{partialx^{2}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="111" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img112.gif"
 ALT="$\displaystyle \ensuremath{\frac{\partial^2 y}{\partial t^{2}}}= c^2 \ensuremath{\frac{\partial^2 y}{\partial x^{2}}}$">|; 

$key = q/(x+jy)(v+jw)=xv+jyv+jwx+j^2yw=(xv-yw)+j(xw+yv);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="578" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img53.gif"
 ALT="$ (x + jy)(v + jw) = xv + jyv + jwx + j^2yw = (xv-yw) + j(xw+yv)$">|; 

$key = q/displaystyleF_i=rhoDeltaxensuremath{frac{partial^2y}{partialt^{2}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="115" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img107.gif"
 ALT="$\displaystyle F_i = \rho \Delta x \ensuremath{\frac{\partial^2 y}{\partial t^{2}}}$">|; 

$key = q/phi;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img31.gif"
 ALT="$ \phi$">|; 

$key = q/y(x,t)=cosomega_0tsin(pixslashL);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="219" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img130.gif"
 ALT="$ y(x,t) = \cos \omega_0 t \sin(\pi x/L)$">|; 

$key = q/displaystylea_1e^{jomegat}+a_2e^{jomega+t}e^{jdeltat};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="159" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img93.gif"
 ALT="$\displaystyle a_1 e^{j\omega t} + a_2 e^{j\omega+ t} e^{j\delta t}$">|; 

$key = q/z+z^*;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="54" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img82.gif"
 ALT="$ z + z^*$">|; 

$key = q/{partial^2y}slash{partialt^{2}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="68" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img115.gif"
 ALT="$ {\partial^2 y}/{\partial t^{2}}$">|; 

$key = q/displaystylemathbf{v}=x+jy;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="94" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img45.gif"
 ALT="$\displaystyle \mathbf{v} = x + j y$">|; 

$key = q/displaystyleensuremath{frac{partial^2y}{partialt^{2}}}=frac{P}{rho}ensuremath{frac{partial^2y}{partialx^{2}}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="113" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img111.gif"
 ALT="$\displaystyle \ensuremath{\frac{\partial^2 y}{\partial t^{2}}}= \frac{P}{\rho} \ensuremath{\frac{\partial^2 y}{\partial x^{2}}}$">|; 

$key = q/rhoDeltax;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="41" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img108.gif"
 ALT="$ \rho \Delta x$">|; 

$key = q/c_k;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img134.gif"
 ALT="$ c_k$">|; 

$key = q/y(x,t)=f(t-xslashc);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="164" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img118.gif"
 ALT="$ y(x,t) = f(t-x/c)$">|; 

$key = q/1times10^{-6};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.gif"
 ALT="$ 1 \times 10^{-6}$">|; 

$key = q/{partial^2y}slash{partialx^{2}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="72" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img116.gif"
 ALT="$ {\partial^2 y}/{\partial x^{2}}$">|; 

$key = q/F_i;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.gif"
 ALT="$ F_i$">|; 

$key = q/Rangletheta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="39" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img49.gif"
 ALT="$ R\angle\theta$">|; 

$key = q/displaystyleensuremath{frac{mathrm{d}}{mathrm{d}t}}E(theta);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="64" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img69.gif"
 ALT="$\displaystyle \ensuremath{\frac{\mathrm{d} }{\mathrm{d} t}}E(\theta)$">|; 

$key = q/phi_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="23" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img39.gif"
 ALT="$ \phi_2$">|; 

$key = q/displaystylee^{jomega+t}(a_1+a_2e^{jdeltat});MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="144" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img94.gif"
 ALT="$\displaystyle e^{j\omega+ t} (a_1 + a_2 e^{j\delta t})$">|; 

$key = q/a;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.gif"
 ALT="$ a$">|; 

$key = q/displaystyle2x^2+9t^2x;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="90" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img104.gif"
 ALT="$\displaystyle 2x^2 + 9t^2x$">|; 

$key = q/y(x,t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img98.gif"
 ALT="$ y(x,t)$">|; 

$key = q/{figure}vspace{2in}textit{{bfseries{AskMikeforsketch.}{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="18" BORDER="0"
 SRC="|."$dir".q|img6.gif"
 ALT="\begin{figure}\vspace{2in}
\textit{\bfseries Ask Mike for sketch.}
\end{figure}">|; 

$key = q/2jImag(z);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="73" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img85.gif"
 ALT="$ 2j\Imag(z)$">|; 

$key = q/x+jy;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="57" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img50.gif"
 ALT="$ x + jy$">|; 

$key = q/i;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img48.gif"
 ALT="$ i$">|; 

$key = q/x(t)=0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img33.gif"
 ALT="$ x(t)=0$">|; 

$key = q/L;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img122.gif"
 ALT="$ L$">|; 

$key = q/R_1angletheta_1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img58.gif"
 ALT="$ R_1\angle\theta_1$">|; 

$key = q/a_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img37.gif"
 ALT="$ a_2$">|; 

$key = q/T;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img126.gif"
 ALT="$ T$">|; 

$key = q/F_i=F_e;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.gif"
 ALT="$ F_i = F_e$">|; 

$key = q/F_e=-kx;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="85" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.gif"
 ALT="$ F_e = -kx$">|; 

$key = q/y;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.gif"
 ALT="$ y$">|; 

$key = q/displaystyley(x,t)=sum_{k=1}^inftyc_ke^{jkomega_0t}sin(kpixslashL);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="265" HEIGHT="70" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img133.gif"
 ALT="$\displaystyle y(x,t) = \sum_{k=1}^\infty c_k e^{jk\omega_0 t} \sin(k\pi x/L)$">|; 

$key = q/z=x+jy;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="92" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img55.gif"
 ALT="$ z = x + jy$">|; 

$key = q/displaystylesum_{k=1}^inftyc_ksin(kpixslashL);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="147" HEIGHT="70" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img137.gif"
 ALT="$\displaystyle \sum_{k=1}^\infty c_k \sin(k\pi x/L)$">|; 

$key = q/displaystylex;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="15" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img100.gif"
 ALT="$\displaystyle x$">|; 

$key = q/displaystyley(x,t)=e^{jkomega_0t}sin(kpixslashL);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="218" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img131.gif"
 ALT="$\displaystyle y(x,t) = e^{jk\omega_0 t} \sin(k\pi x/L)$">|; 

$key = q/displaystyleE(theta)=costheta+jsintheta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="177" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img62.gif"
 ALT="$\displaystyle E(\theta) = \cos\theta + j\sin\theta$">|; 

$key = q/t=0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img32.gif"
 ALT="$ t=0$">|; 

$key = q/f(t)=-g(t);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="108" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img123.gif"
 ALT="$ f(t) = -g(t)$">|; 

$key = q/displaystylee^{jtheta};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="27" HEIGHT="42" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img68.gif"
 ALT="$\displaystyle e^{j\theta}$">|; 

$key = q/e^{jdeltat};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img96.gif"
 ALT="$ e^{j\delta t}$">|; 

$key = q/z^*=x-jy;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="100" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img79.gif"
 ALT="$ z^*=x-jy$">|; 

$key = q/y(0,t)=0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="88" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img120.gif"
 ALT="$ y(0,t) =
0$">|; 

$key = q/e^{jtheta}=costheta+jsintheta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="160" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img71.gif"
 ALT="$ e^{j\theta} = \cos\theta + j\sin\theta$">|; 

$key = q/omega;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img27.gif"
 ALT="$ \omega$">|; 

$key = q/theta=arctan(yslashx);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="136" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img57.gif"
 ALT="$ \theta =
\arctan(y/x)$">|; 

$key = q/mathbf{u}+mathbf{v};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img44.gif"
 ALT="$ \mathbf{u}+\mathbf{v}$">|; 

$key = q/displaystyleensuremath{frac{partial(2x^2t+3t^3x)}{partialt}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="126" HEIGHT="64" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img103.gif"
 ALT="$\displaystyle \ensuremath{\frac{\partial (2x^2t + 3t^3x)}{\partial t}}$">|; 

$key = q/t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img97.gif"
 ALT="$ t$">|; 

$key = q/theta(t)=omegat;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img88.gif"
 ALT="$ \theta(t) = \omega t$">|; 

$key = q/omega_0=2pif_0=picslashL;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="153" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img128.gif"
 ALT="$ \omega_0 = 2\pi f_0 = \pi
c/L$">|; 

$key = q/F_i=ma;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.gif"
 ALT="$ F_i =
ma$">|; 

$key = q/omega=sqrt{kslashm};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="44" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img28.gif"
 ALT="$ \omega = \sqrt{k/m}$">|; 

$key = q/R=|z|=sqrt{x^2+y^2};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="167" HEIGHT="44" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img56.gif"
 ALT="$ R = \vert z\vert = \sqrt{x^2+y^2}$">|; 

$key = q/zz^*;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="31" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img86.gif"
 ALT="$ zz^*$">|; 

$key = q/omega+delta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img90.gif"
 ALT="$ \omega + \delta$">|; 

$key = q/mathbf{u};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img42.gif"
 ALT="$ \mathbf{u}$">|; 

$key = q/z^*;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img78.gif"
 ALT="$ z^*$">|; 

$key = q/y(L,t)=0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="91" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img121.gif"
 ALT="$ y(L,t) = 0$">|; 

$key = q/z_1z_2=R_1R_2e^{j(theta_1+theta_2)};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="169" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img77.gif"
 ALT="$ z_1z_2 =
R_1R_2e^{j(\theta_1+\theta_2)}$">|; 

$key = q/cosomegat=sin(omegat+pislash2);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="187" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img29.gif"
 ALT="$ \cos\omega t = \sin(\omega t +
\pi/2)$">|; 

$key = q/E(theta);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="44" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img61.gif"
 ALT="$ E(\theta)$">|; 

$key = q/a_1cos(omegat+phi_1)+a_2cos(omegat+phi_2);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="269" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img35.gif"
 ALT="$ a_1 \cos(\omega t + \phi_1) + a_2
\cos(\omega t + \phi_2)$">|; 

$key = q/displaystylea=-frac{k}{m}x;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="85" HEIGHT="60" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.gif"
 ALT="$\displaystyle a = -\frac{k}{m} x$">|; 

$key = q/R_2angletheta_2;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img59.gif"
 ALT="$ R_2\angle\theta_2$">|; 

$key = q/displaystyleensuremath{frac{partial(xt)}{partialt}};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="51" HEIGHT="62" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img99.gif"
 ALT="$\displaystyle \ensuremath{\frac{\partial (xt)}{\partial t}}$">|; 

$key = q/phi=theta(0);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="74" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img41.gif"
 ALT="$ \phi = \theta(0)$">|; 

$key = q/theta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img63.gif"
 ALT="$ \theta$">|; 

$key = q/{figure}textit{{bfseries{AskMikeforsketch.}{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="161" HEIGHT="18" BORDER="0"
 SRC="|."$dir".q|img9.gif"
 ALT="\begin{figure}\textit{\bfseries Ask Mike for sketch.}
\end{figure}">|; 

$key = q/v=mathrm{d}xslashmathrm{d}t;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="87" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img21.gif"
 ALT="$ v = \mathrm{d}x/\mathrm{d}t$">|; 

$key = q/{window}[0,r,<comment_mark>19{{fbox{parbox{0.4textwidth}{smalltextbf{ImportantTethenweanalyzethedatatoproduceareportoncropconditions.{window};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="745" HEIGHT="544" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.gif"
 ALT="\begin{window}[0,r,%%
{\fbox{\parbox{0.4\textwidth}{\small \textbf{Important Ter...
...nd then we analyze the data to produce a report on
crop conditions.
\end{window}">|; 

$key = q/z-z^*;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="55" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img84.gif"
 ALT="$ z - z^*$">|; 

$key = q/rho;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img109.gif"
 ALT="$ \rho$">|; 

$key = q/delta;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img138.gif"
 ALT="$ \delta$">|; 

$key = q/j;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img46.gif"
 ALT="$ j$">|; 

$key = q/F_e;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.gif"
 ALT="$ F_e$">|; 

$key = q/z_1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img75.gif"
 ALT="$ z_1$">|; 

$key = q/displaystyley(x,t)=e^{jomega_0t}sin(pixslashL);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="200" HEIGHT="41" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img129.gif"
 ALT="$\displaystyle y(x,t) = e^{j\omega_0 t} \sin(\pi x/L)$">|; 

$key = q/x(t)=1;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="71" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img34.gif"
 ALT="$ x(t)=1$">|; 

$key = q/deltallomega;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="56" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img91.gif"
 ALT="$ \delta\ll\omega$">|; 

$key = q/f_0=1slashT=cslash2L;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="144" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img127.gif"
 ALT="$ f_0 = 1/T = c/2L$">|; 

$key = q/displaystyley(x,t)=f(t-xslashc)+g(t+xslashc);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="269" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img119.gif"
 ALT="$\displaystyle y(x,t) = f(t - x/c) + g(t + x/c)$">|; 

$key = q/Re^{jtheta};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="42" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img74.gif"
 ALT="$ Re^{j\theta}$">|; 

$key = q/400times10^{-9};MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="93" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img3.gif"
 ALT="$ 400 \times 10^{-9}$">|; 

$key = q/jE(theta);MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="52" HEIGHT="37" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img65.gif"
 ALT="$ jE(\theta)$">|; 

$key = q/omega_0;MSF=1.6;LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="24" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img132.gif"
 ALT="$ \omega_0$">|; 

1;

