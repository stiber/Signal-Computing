# LaTeX2HTML 2K.1beta (1.50)
# Associate internals original text with physical files.


$key = q/eq:string-inertia/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:wave/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin-rect/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:fseries-x/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:string/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:modes/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:standing-wave/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:pow-rot/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:trav-wave/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/fg:tuningfork/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/fg:crt/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin-ddt/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:tuningfork/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/fg:raster/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:gen-vib/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:gensine/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:phasor/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:vibration/;
$ref_files{$key} = "$dir".q|physical-signals.html|; 
$noresave{$key} = "$nosave";

1;

