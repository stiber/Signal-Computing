# LaTeX2HTML 2K.1beta (1.50)
# Associate labels original text with physical files.


$key = q/eq:string-inertia/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:wave/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin-rect/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:fseries-x/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:string/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:modes/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:standing-wave/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:pow-rot/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:trav-wave/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/fg:tuningfork/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/fg:crt/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin-ddt/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:tuningfork/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/fg:raster/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:gen-vib/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:gensine/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:phasor/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

$key = q/eq:vibration/;
$external_labels{$key} = "$URL/" . q|physical-signals.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2K.1beta (1.50)
# labels from external_latex_labels array.


$key = q/eq:string-inertia/;
$external_latex_labels{$key} = q|1-14|; 
$noresave{$key} = "$nosave";

$key = q/eq:wave/;
$external_latex_labels{$key} = q|1-16|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin-rect/;
$external_latex_labels{$key} = q|1-7|; 
$noresave{$key} = "$nosave";

$key = q/eq:fseries-x/;
$external_latex_labels{$key} = q|1-23|; 
$noresave{$key} = "$nosave";

$key = q/eq:string/;
$external_latex_labels{$key} = q|1-15|; 
$noresave{$key} = "$nosave";

$key = q/eq:modes/;
$external_latex_labels{$key} = q|1-20|; 
$noresave{$key} = "$nosave";

$key = q/eq:standing-wave/;
$external_latex_labels{$key} = q|1-19|; 
$noresave{$key} = "$nosave";

$key = q/eq:pow-rot/;
$external_latex_labels{$key} = q|1-11|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin/;
$external_latex_labels{$key} = q|1-10|; 
$noresave{$key} = "$nosave";

$key = q/eq:trav-wave/;
$external_latex_labels{$key} = q|1-17|; 
$noresave{$key} = "$nosave";

$key = q/fg:tuningfork/;
$external_latex_labels{$key} = q|1.3|; 
$noresave{$key} = "$nosave";

$key = q/fg:crt/;
$external_latex_labels{$key} = q|1.1|; 
$noresave{$key} = "$nosave";

$key = q/eq:cmplx-sin-ddt/;
$external_latex_labels{$key} = q|1-8|; 
$noresave{$key} = "$nosave";

$key = q/eq:tuningfork/;
$external_latex_labels{$key} = q|1-2|; 
$noresave{$key} = "$nosave";

$key = q/fg:raster/;
$external_latex_labels{$key} = q|1.2|; 
$noresave{$key} = "$nosave";

$key = q/eq:gen-vib/;
$external_latex_labels{$key} = q|1-21|; 
$noresave{$key} = "$nosave";

$key = q/eq:gensine/;
$external_latex_labels{$key} = q|1-5|; 
$noresave{$key} = "$nosave";

$key = q/eq:phasor/;
$external_latex_labels{$key} = q|1-12|; 
$noresave{$key} = "$nosave";

$key = q/eq:vibration/;
$external_latex_labels{$key} = q|1-18|; 
$noresave{$key} = "$nosave";

1;

